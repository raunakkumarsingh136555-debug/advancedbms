SET SERVEROUTPUT ON
DECLARE
    xempid    NUMBER := &xempid;
    xsalary   NUMBER;
    null_sal  EXCEPTION;
BEGIN
    SELECT salary INTO xsalary FROM emp WHERE emp_id = xempid;

    IF xsalary IS NULL THEN
        RAISE null_sal;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Salary is = ' || xsalary);
    END IF;

EXCEPTION
    WHEN null_sal THEN
        RAISE_APPLICATION_ERROR(-20202, 'Salary is not entered');
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Employee ID ' || xempid || ' does not exist.');
    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Multiple records found for Employee ID ' || xempid);
END;
/